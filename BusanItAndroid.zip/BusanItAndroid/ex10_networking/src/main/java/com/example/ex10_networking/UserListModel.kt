package com.example.ex10_networking

data class UserListModel(
    var data: MutableList<UserModel>
)
