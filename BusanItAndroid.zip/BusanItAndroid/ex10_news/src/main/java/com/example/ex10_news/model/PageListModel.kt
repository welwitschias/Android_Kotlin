package com.example.ex10_news.model

data class PageListModel(
    val articles: MutableList<ItemModel>?
)